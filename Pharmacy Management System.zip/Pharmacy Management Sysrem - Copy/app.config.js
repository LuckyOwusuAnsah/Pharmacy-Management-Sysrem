/*app.config.js*/
let appConfig = {
	UPDATE_SERVER: "https://download.pharmaspot.patternsdigital.com",
	// about 
	COPYRIGHT_YEAR: "2025",
}

module.exports={appConfig}