---
description: Repository Information Overview
alwaysApply: true
---


## Summary
Pharmacy management system is a cross-platform Point of Sale system designed for pharmacies, built with Electron to streamline operations and enhance customer service. It provides features like multi-PC support, receipt printing, product search, staff accounts with permissions, and inventory management.



## Features
- **Multi-PC support for collaborative pharmacy operations
- **Receipt printing with customizable templates
- **Product search with advanced filtering and categorization
- **Staff accounts with role-based permissions
- **Inventory management with stock alerts and expiration tracking
- **Customer management and prescription history
- **Sales reporting and analytics dashboard
- **Multi-store capability for offline operations and data synchronization
- **Barcode scanning and generation for quick product identification
- **Supplier management with order tracking and history
- **Backup and restore functionality for data protection
- **Audit logging for compliance and security tracking
***Cross-platform compatibility on Windows, macOS, and Linux**
- **Role-based access control for different user levels**


## Language & Runtime
**Language**: JavaScript (Node.js)
**Version**: Node.js 18.x
**Build System**: Electron Forge, Gulp
**Package Manager**: npm

## Dependencies
**Main Dependencies**:
- Electron v22.3.27 (Electron framework)
- Express v4.21.2 (Web server)
- @seald-io/nedb v4.0.3 (Database)
- Socket.io v4.8.0 (Real-time communication)
- Electron-updater v6.3.0 (Auto-updates)
- Moment v2.29.4 (Date handling)
- JsPDF v3.0.1 (PDF generation)

**Development Dependencies**:
- Jest v29.7.0 (Testing)
- Gulp v5.0.0 (Asset bundling)
- Electron-forge v6.0.4 (Packaging)
- Nodemon v3.0.1 (Development server)
- Browser-sync v3.0.3 (Live reload)

## Build & Installation
```bash
# Install dependencies
npm install

# Development mode
npm run electron

# Build application
npm run make

# Package for Windows
npm run package-win

# Run tests
npm run test

# Bundle assets
gulp
```

## Testing
**Framework**: Jest
**Test Location**: /tests directory
**Configuration**: jest.config.ts
**Run Command**:
```bash
npm run test
```
